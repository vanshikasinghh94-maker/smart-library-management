"""
Unit Tests for Smart Library System
Run: pytest tests/ -v
"""

import pytest
import json
from datetime import date, timedelta
from app import create_app, db, bcrypt
from app.models import User, Book, Category, BorrowingHistory
from config import TestingConfig


@pytest.fixture
def app():
    app = create_app(TestingConfig)
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def librarian_token(client):
    with client.application.app_context():
        user = User(
            name='Test Librarian', email='lib@test.com',
            password_hash=bcrypt.generate_password_hash('lib123').decode('utf-8'),
            role='librarian'
        )
        db.session.add(user)
        db.session.commit()

    res = client.post('/api/auth/login', json={'email': 'lib@test.com', 'password': 'lib123'})
    return json.loads(res.data)['access_token']


@pytest.fixture
def student_token(client):
    with client.application.app_context():
        user = User(
            name='Test Student', email='stu@test.com',
            password_hash=bcrypt.generate_password_hash('stu123').decode('utf-8'),
            role='student', enrollment_no='TEST001'
        )
        db.session.add(user)
        db.session.commit()

    res = client.post('/api/auth/login', json={'email': 'stu@test.com', 'password': 'stu123'})
    return json.loads(res.data)['access_token']


class TestAuth:
    def test_register(self, client):
        res = client.post('/api/auth/register', json={
            'name': 'New User', 'email': 'new@test.com',
            'password': 'pass123', 'role': 'student'
        })
        assert res.status_code == 201
        assert b'registered' in res.data

    def test_login_success(self, client, librarian_token):
        assert librarian_token is not None

    def test_login_wrong_password(self, client):
        res = client.post('/api/auth/login', json={'email': 'lib@test.com', 'password': 'wrong'})
        assert res.status_code == 401

    def test_profile_requires_auth(self, client):
        res = client.get('/api/auth/profile')
        assert res.status_code == 401

    def test_profile_with_token(self, client, student_token):
        res = client.get('/api/auth/profile', headers={'Authorization': f'Bearer {student_token}'})
        assert res.status_code == 200
        assert b'stu@test.com' in res.data


class TestBooks:
    def test_get_books(self, client, student_token):
        res = client.get('/api/books/', headers={'Authorization': f'Bearer {student_token}'})
        assert res.status_code == 200

    def test_add_book_as_librarian(self, client, librarian_token):
        res = client.post('/api/books/', json={
            'title': 'Test Book', 'author': 'Test Author', 'total_copies': 3
        }, headers={'Authorization': f'Bearer {librarian_token}'})
        assert res.status_code == 201
        assert b'Test Book' in res.data

    def test_add_book_forbidden_for_student(self, client, student_token):
        res = client.post('/api/books/', json={
            'title': 'Hack', 'author': 'Hacker'
        }, headers={'Authorization': f'Bearer {student_token}'})
        assert res.status_code == 403

    def test_search_books(self, client, librarian_token, student_token):
        client.post('/api/books/', json={'title': 'Python Guide', 'author': 'Smith'},
                    headers={'Authorization': f'Bearer {librarian_token}'})
        res = client.get('/api/books/?search=Python',
                         headers={'Authorization': f'Bearer {student_token}'})
        assert res.status_code == 200
        data = json.loads(res.data)
        assert data['total'] >= 1


class TestBorrowing:
    def _setup_book_and_student(self, app):
        with app.app_context():
            student = User.query.filter_by(email='stu@test.com').first()
            book = Book(title='Borrow Me', author='Auth', total_copies=2, available_copies=2)
            db.session.add(book)
            db.session.commit()
            return student.id, book.id

    def test_issue_and_return(self, client, librarian_token, student_token, app):
        student_id, book_id = self._setup_book_and_student(app)

        # Issue
        res = client.post('/api/borrowing/issue',
                          json={'user_id': student_id, 'book_id': book_id},
                          headers={'Authorization': f'Bearer {librarian_token}'})
        assert res.status_code == 201
        record_id = json.loads(res.data)['record']['id']

        # Return
        res = client.post(f'/api/borrowing/return/{record_id}',
                          headers={'Authorization': f'Bearer {librarian_token}'})
        assert res.status_code == 200
        assert b'returned' in res.data

    def test_issue_unavailable_book(self, client, librarian_token, student_token, app):
        with app.app_context():
            student = User.query.filter_by(email='stu@test.com').first()
            book = Book(title='Rare Book', author='Auth', total_copies=1, available_copies=0)
            db.session.add(book)
            db.session.commit()
            sid, bid = student.id, book.id

        res = client.post('/api/borrowing/issue',
                          json={'user_id': sid, 'book_id': bid},
                          headers={'Authorization': f'Bearer {librarian_token}'})
        assert res.status_code == 400


class TestFineCalculation:
    def test_no_fine_on_time(self, app):
        with app.app_context():
            record = BorrowingHistory(
                user_id=1, book_id=1,
                issue_date=date.today() - timedelta(days=5),
                due_date=date.today() + timedelta(days=2)
            )
            assert record.calculate_fine() == 0

    def test_fine_for_overdue(self, app):
        with app.app_context():
            record = BorrowingHistory(
                user_id=1, book_id=1,
                issue_date=date.today() - timedelta(days=20),
                due_date=date.today() - timedelta(days=6)
            )
            fine = record.calculate_fine(fine_per_day=5)
            assert fine == 30  # 6 days × ₹5
