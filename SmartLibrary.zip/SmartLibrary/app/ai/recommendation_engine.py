"""
AI Recommendation Engine
Hybrid model combining Collaborative Filtering (60%) + Content-Based Filtering (40%)
Uses Scikit-learn for ML processing
"""

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from app.models import BorrowingHistory, Book, User
from config import Config


class RecommendationEngine:
    """
    Hybrid recommendation engine combining:
    - Collaborative Filtering: user-item matrix with cosine similarity
    - Content-Based Filtering: TF-IDF on book title + author + category + description
    Final score = 0.6 * collaborative_score + 0.4 * content_score
    """

    def __init__(self):
        self.cf_weight = Config.COLLABORATIVE_WEIGHT      # 0.6
        self.cb_weight = Config.CONTENT_BASED_WEIGHT      # 0.4
        self.top_n = Config.TOP_RECOMMENDATIONS           # 5

    def _build_user_item_matrix(self, borrowings_df, books_df):
        """Build user-item interaction matrix from borrowing history"""
        if borrowings_df.empty:
            return pd.DataFrame()

        # Count borrowings per user-book pair (implicit rating)
        matrix = borrowings_df.groupby(['user_id', 'book_id']).size().reset_index(name='count')
        pivot = matrix.pivot(index='user_id', columns='book_id', values='count').fillna(0)
        return pivot

    def _collaborative_filtering(self, user_id, user_item_matrix, all_book_ids):
        """
        User-based collaborative filtering.
        Finds similar users and recommends books they read that target user hasn't.
        Returns dict of {book_id: score}
        """
        if user_id not in user_item_matrix.index or len(user_item_matrix) < 2:
            return {}

        user_vector = user_item_matrix.loc[user_id].values.reshape(1, -1)
        similarity_scores = cosine_similarity(user_vector, user_item_matrix.values)[0]

        # Get top-10 similar users (excluding self)
        user_indices = np.argsort(similarity_scores)[::-1]
        similar_users = [
            (user_item_matrix.index[i], similarity_scores[i])
            for i in user_indices
            if user_item_matrix.index[i] != user_id
        ][:10]

        if not similar_users:
            return {}

        # Books already read by target user
        already_read = set(user_item_matrix.columns[user_item_matrix.loc[user_id] > 0])

        # Aggregate scores from similar users
        book_scores = {}
        for sim_user_id, sim_score in similar_users:
            sim_user_books = user_item_matrix.loc[sim_user_id]
            for book_id in user_item_matrix.columns:
                if book_id not in already_read and sim_user_books[book_id] > 0:
                    book_scores[book_id] = book_scores.get(book_id, 0) + sim_score * sim_user_books[book_id]

        # Normalize
        if book_scores:
            max_score = max(book_scores.values())
            if max_score > 0:
                book_scores = {k: v / max_score for k, v in book_scores.items()}

        return book_scores

    def _content_based_filtering(self, user_id, borrowings_df, books_df):
        """
        Content-based filtering using TF-IDF on book metadata.
        Returns dict of {book_id: score}
        """
        if borrowings_df.empty or books_df.empty:
            return {}

        # Build content string for each book
        books_df = books_df.copy()
        books_df['content'] = (
            books_df['title'].fillna('') + ' ' +
            books_df['author'].fillna('') + ' ' +
            books_df['category'].fillna('') + ' ' +
            books_df['description'].fillna('')
        )

        tfidf = TfidfVectorizer(stop_words='english', max_features=5000)
        try:
            tfidf_matrix = tfidf.fit_transform(books_df['content'])
        except Exception:
            return {}

        book_id_to_idx = {row['id']: idx for idx, row in books_df.iterrows()}

        # Get books read by user
        user_books = borrowings_df[borrowings_df['user_id'] == user_id]['book_id'].unique()
        if len(user_books) == 0:
            return {}

        # Average TF-IDF vector of books user has read
        user_indices = [book_id_to_idx[bid] for bid in user_books if bid in book_id_to_idx]
        if not user_indices:
            return {}

        user_profile = np.asarray(tfidf_matrix[user_indices].mean(axis=0))
        similarity = cosine_similarity(user_profile, tfidf_matrix)[0]

        already_read = set(user_books)
        book_scores = {}
        for idx, score in enumerate(similarity):
            book_id = books_df.iloc[idx]['id']
            if book_id not in already_read:
                book_scores[book_id] = float(score)

        return book_scores

    def get_recommendations(self, user_id):
        """
        Main recommendation method.
        Returns list of recommended Book objects.
        """
        from app import db

        # Load data
        borrowings = BorrowingHistory.query.all()
        books = Book.query.filter_by(is_active=True).all()

        if not borrowings or not books:
            # Fallback: return popular books
            return self._popular_books(user_id, books)

        borrowings_df = pd.DataFrame([{
            'user_id': b.user_id,
            'book_id': b.book_id
        } for b in borrowings])

        books_df = pd.DataFrame([{
            'id': b.id,
            'title': b.title,
            'author': b.author,
            'category': b.category.name if b.category else '',
            'description': b.description or ''
        } for b in books])

        all_book_ids = books_df['id'].tolist()

        # Build user-item matrix
        user_item_matrix = self._build_user_item_matrix(borrowings_df, books_df)

        # Get scores from both models
        cf_scores = self._collaborative_filtering(user_id, user_item_matrix, all_book_ids)
        cb_scores = self._content_based_filtering(user_id, borrowings_df, books_df)

        # Hybrid scoring
        all_candidate_ids = set(cf_scores.keys()) | set(cb_scores.keys())
        if not all_candidate_ids:
            return self._popular_books(user_id, books)

        hybrid_scores = {}
        for book_id in all_candidate_ids:
            cf = cf_scores.get(book_id, 0)
            cb = cb_scores.get(book_id, 0)
            hybrid_scores[book_id] = self.cf_weight * cf + self.cb_weight * cb

        # Sort and return top-N available books
        sorted_books = sorted(hybrid_scores.items(), key=lambda x: x[1], reverse=True)
        book_map = {b.id: b for b in books}

        result = []
        for book_id, score in sorted_books:
            book = book_map.get(book_id)
            if book and book.available_copies > 0:
                result.append(book)
            if len(result) >= self.top_n:
                break

        return result

    def _popular_books(self, user_id, books):
        """Fallback: return most borrowed available books"""
        from app.models import BorrowingHistory
        from app import db

        popular = db.session.query(
            BorrowingHistory.book_id,
            db.func.count(BorrowingHistory.id).label('count')
        ).group_by(BorrowingHistory.book_id).order_by(db.desc('count')).limit(20).all()

        user_books = {b.book_id for b in BorrowingHistory.query.filter_by(user_id=user_id)}
        book_map = {b.id: b for b in books}

        result = []
        for book_id, _ in popular:
            if book_id not in user_books and book_id in book_map:
                book = book_map[book_id]
                if book.available_copies > 0:
                    result.append(book)
            if len(result) >= self.top_n:
                break

        # If still empty, just return first available books
        if not result:
            result = [b for b in books if b.available_copies > 0][:self.top_n]

        return result
