"""
Flask Application Factory
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from flask_mail import Mail
from flask_apscheduler import APScheduler
from config import Config

db = SQLAlchemy()
jwt = JWTManager()
bcrypt = Bcrypt()
mail = Mail()
scheduler = APScheduler()


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    bcrypt.init_app(app)
    mail.init_app(app)
    scheduler.init_app(app)
    scheduler.start()

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.books import books_bp
    from app.routes.borrowing import borrowing_bp
    from app.routes.recommendations import rec_bp
    from app.routes.admin import admin_bp
    from app.routes.notifications import notif_bp

    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(books_bp, url_prefix='/api/books')
    app.register_blueprint(borrowing_bp, url_prefix='/api/borrowing')
    app.register_blueprint(rec_bp, url_prefix='/api/recommendations')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    app.register_blueprint(notif_bp, url_prefix='/api/notifications')

    # Serve frontend
    from flask import render_template

    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/dashboard')
    def dashboard():
        return render_template('student/dashboard.html')

    @app.route('/admin')
    def admin():
        return render_template('admin/dashboard.html')

    with app.app_context():
        db.create_all()

    return app
