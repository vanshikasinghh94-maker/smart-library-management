"""
Notifications Routes + APScheduler Jobs
Daily job sends due-date reminders, overdue alerts, new arrival alerts
"""

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import date, timedelta
from app import db
from app.models import Notification, BorrowingHistory, Book, User

notif_bp = Blueprint('notifications', __name__)


# ── Scheduled jobs (registered in create_app via APScheduler) ──────────────

def send_due_date_reminders():
    """Runs daily. Sends reminder 3 days before due date."""
    from app import create_app
    app = create_app()
    with app.app_context():
        reminder_date = date.today() + timedelta(days=3)
        records = BorrowingHistory.query.filter(
            BorrowingHistory.is_returned == False,
            BorrowingHistory.due_date == reminder_date
        ).all()
        for record in records:
            notif = Notification(
                user_id=record.user_id,
                title='Book Due Soon',
                message=f'"{record.book.title}" is due on {record.due_date}. Please return it on time.',
                type='due_date'
            )
            db.session.add(notif)
        db.session.commit()


def send_overdue_alerts():
    """Runs daily. Notifies students with overdue books."""
    from app import create_app
    app = create_app()
    with app.app_context():
        today = date.today()
        overdue = BorrowingHistory.query.filter(
            BorrowingHistory.is_returned == False,
            BorrowingHistory.due_date < today
        ).all()
        for record in overdue:
            days_late = (today - record.due_date).days
            fine = record.calculate_fine()
            notif = Notification(
                user_id=record.user_id,
                title='Overdue Book Alert',
                message=(
                    f'"{record.book.title}" is {days_late} day(s) overdue. '
                    f'Fine accrued: ₹{fine:.2f}. Please return immediately.'
                ),
                type='overdue'
            )
            db.session.add(notif)
        db.session.commit()


# ── API Endpoints ──────────────────────────────────────────────────────────

@notif_bp.route('/', methods=['GET'])
@jwt_required()
def get_notifications():
    identity = get_jwt_identity()
    notifications = Notification.query.filter_by(
        user_id=identity['id']
    ).order_by(Notification.created_at.desc()).limit(50).all()

    return jsonify([n.to_dict() for n in notifications]), 200


@notif_bp.route('/unread-count', methods=['GET'])
@jwt_required()
def unread_count():
    identity = get_jwt_identity()
    count = Notification.query.filter_by(user_id=identity['id'], is_read=False).count()
    return jsonify({'unread_count': count}), 200


@notif_bp.route('/<int:notif_id>/read', methods=['POST'])
@jwt_required()
def mark_read(notif_id):
    identity = get_jwt_identity()
    notif = Notification.query.filter_by(id=notif_id, user_id=identity['id']).first_or_404()
    notif.is_read = True
    db.session.commit()
    return jsonify({'message': 'Marked as read'}), 200


@notif_bp.route('/mark-all-read', methods=['POST'])
@jwt_required()
def mark_all_read():
    identity = get_jwt_identity()
    Notification.query.filter_by(user_id=identity['id'], is_read=False).update({'is_read': True})
    db.session.commit()
    return jsonify({'message': 'All notifications marked as read'}), 200
