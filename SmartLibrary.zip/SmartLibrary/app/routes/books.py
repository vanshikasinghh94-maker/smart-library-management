"""
Books Routes
CRUD operations for book management
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from app.models import Book, Category

books_bp = Blueprint('books', __name__)


def librarian_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        identity = get_jwt_identity()
        if identity['role'] != 'librarian':
            return jsonify({'error': 'Librarian access required'}), 403
        return fn(*args, **kwargs)
    return wrapper


@books_bp.route('/', methods=['GET'])
@jwt_required()
def get_books():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '')
    category_id = request.args.get('category_id', type=int)

    query = Book.query.filter_by(is_active=True)

    if search:
        query = query.filter(
            db.or_(
                Book.title.ilike(f'%{search}%'),
                Book.author.ilike(f'%{search}%'),
                Book.isbn.ilike(f'%{search}%')
            )
        )
    if category_id:
        query = query.filter_by(category_id=category_id)

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return jsonify({
        'books': [b.to_dict() for b in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'current_page': page
    }), 200


@books_bp.route('/<int:book_id>', methods=['GET'])
@jwt_required()
def get_book(book_id):
    book = Book.query.get_or_404(book_id)
    return jsonify(book.to_dict()), 200


@books_bp.route('/', methods=['POST'])
@jwt_required()
@librarian_required
def add_book():
    data = request.get_json()
    required = ['title', 'author']
    if not all(k in data for k in required):
        return jsonify({'error': 'Title and author are required'}), 400

    book = Book(
        title=data['title'],
        author=data['author'],
        isbn=data.get('isbn'),
        category_id=data.get('category_id'),
        publisher=data.get('publisher'),
        year_published=data.get('year_published'),
        description=data.get('description'),
        total_copies=data.get('total_copies', 1),
        available_copies=data.get('total_copies', 1)
    )
    db.session.add(book)
    db.session.commit()
    return jsonify({'message': 'Book added', 'book': book.to_dict()}), 201


@books_bp.route('/<int:book_id>', methods=['PUT'])
@jwt_required()
@librarian_required
def update_book(book_id):
    book = Book.query.get_or_404(book_id)
    data = request.get_json()

    updatable = ['title', 'author', 'isbn', 'category_id', 'publisher',
                 'year_published', 'description', 'total_copies']
    for field in updatable:
        if field in data:
            setattr(book, field, data[field])

    db.session.commit()
    return jsonify({'message': 'Book updated', 'book': book.to_dict()}), 200


@books_bp.route('/<int:book_id>', methods=['DELETE'])
@jwt_required()
@librarian_required
def delete_book(book_id):
    book = Book.query.get_or_404(book_id)
    book.is_active = False
    db.session.commit()
    return jsonify({'message': 'Book removed from catalogue'}), 200


@books_bp.route('/categories', methods=['GET'])
@jwt_required()
def get_categories():
    categories = Category.query.all()
    return jsonify([c.to_dict() for c in categories]), 200


@books_bp.route('/categories', methods=['POST'])
@jwt_required()
@librarian_required
def add_category():
    data = request.get_json()
    cat = Category(name=data['name'], description=data.get('description'))
    db.session.add(cat)
    db.session.commit()
    return jsonify(cat.to_dict()), 201
