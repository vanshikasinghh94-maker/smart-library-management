from app.routes.auth import auth_bp
from app.routes.books import books_bp
from app.routes.borrowing import borrowing_bp
from app.routes.recommendations import rec_bp
from app.routes.admin import admin_bp
from app.routes.notifications import notif_bp
