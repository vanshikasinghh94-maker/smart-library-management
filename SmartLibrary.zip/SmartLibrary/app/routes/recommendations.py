"""
Recommendations Routes
AI-powered book recommendations endpoint
"""

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.ai.recommendation_engine import RecommendationEngine

rec_bp = Blueprint('recommendations', __name__)


@rec_bp.route('/', methods=['GET'])
@jwt_required()
def get_recommendations():
    identity = get_jwt_identity()
    user_id = identity['id']

    engine = RecommendationEngine()
    books = engine.get_recommendations(user_id)

    return jsonify({
        'recommendations': [b.to_dict() for b in books],
        'count': len(books)
    }), 200
