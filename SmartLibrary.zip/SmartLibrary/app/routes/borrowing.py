"""
Borrowing Routes
Issue, return, and borrowing history management
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import date, timedelta
from app import db
from app.models import Book, BorrowingHistory, User
from config import Config

borrowing_bp = Blueprint('borrowing', __name__)


@borrowing_bp.route('/issue', methods=['POST'])
@jwt_required()
def issue_book():
    identity = get_jwt_identity()
    if identity['role'] != 'librarian':
        return jsonify({'error': 'Only librarians can issue books'}), 403

    data = request.get_json()
    book = Book.query.get(data.get('book_id'))
    student = User.query.get(data.get('user_id'))

    if not book or not student:
        return jsonify({'error': 'Book or user not found'}), 404
    if book.available_copies < 1:
        return jsonify({'error': 'No copies available'}), 400

    # Check if student already has this book
    existing = BorrowingHistory.query.filter_by(
        user_id=student.id, book_id=book.id, is_returned=False
    ).first()
    if existing:
        return jsonify({'error': 'Student already has this book issued'}), 400

    borrow_days = data.get('borrow_days', Config.DEFAULT_BORROW_DAYS)
    record = BorrowingHistory(
        user_id=student.id,
        book_id=book.id,
        issue_date=date.today(),
        due_date=date.today() + timedelta(days=borrow_days),
        issued_by=identity['id']
    )
    book.available_copies -= 1
    db.session.add(record)
    db.session.commit()

    return jsonify({'message': 'Book issued successfully', 'record': record.to_dict()}), 201


@borrowing_bp.route('/return/<int:record_id>', methods=['POST'])
@jwt_required()
def return_book(record_id):
    identity = get_jwt_identity()
    if identity['role'] != 'librarian':
        return jsonify({'error': 'Only librarians can process returns'}), 403

    record = BorrowingHistory.query.get_or_404(record_id)
    if record.is_returned:
        return jsonify({'error': 'Book already returned'}), 400

    record.return_date = date.today()
    record.is_returned = True
    record.fine_amount = record.calculate_fine(Config.FINE_PER_DAY)
    record.book.available_copies += 1

    db.session.commit()
    return jsonify({
        'message': 'Book returned successfully',
        'fine': record.fine_amount,
        'record': record.to_dict()
    }), 200


@borrowing_bp.route('/history', methods=['GET'])
@jwt_required()
def get_history():
    identity = get_jwt_identity()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)

    if identity['role'] == 'librarian':
        user_id = request.args.get('user_id', type=int)
        query = BorrowingHistory.query
        if user_id:
            query = query.filter_by(user_id=user_id)
    else:
        query = BorrowingHistory.query.filter_by(user_id=identity['id'])

    pagination = query.order_by(BorrowingHistory.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    return jsonify({
        'records': [r.to_dict() for r in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages
    }), 200


@borrowing_bp.route('/active', methods=['GET'])
@jwt_required()
def get_active_borrowings():
    identity = get_jwt_identity()
    if identity['role'] == 'librarian':
        records = BorrowingHistory.query.filter_by(is_returned=False).all()
    else:
        records = BorrowingHistory.query.filter_by(
            user_id=identity['id'], is_returned=False
        ).all()

    return jsonify([r.to_dict() for r in records]), 200


@borrowing_bp.route('/overdue', methods=['GET'])
@jwt_required()
def get_overdue():
    identity = get_jwt_identity()
    if identity['role'] != 'librarian':
        return jsonify({'error': 'Librarian access required'}), 403

    today = date.today()
    overdue = BorrowingHistory.query.filter(
        BorrowingHistory.is_returned == False,
        BorrowingHistory.due_date < today
    ).all()

    return jsonify([r.to_dict() for r in overdue]), 200
