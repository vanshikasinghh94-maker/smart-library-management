"""
Admin Routes
Analytics, reporting, and user management for librarians
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func
from datetime import date, timedelta
from app import db
from app.models import Book, User, BorrowingHistory, Category

admin_bp = Blueprint('admin', __name__)


def librarian_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        identity = get_jwt_identity()
        if identity['role'] != 'librarian':
            return jsonify({'error': 'Librarian access required'}), 403
        return fn(*args, **kwargs)
    return wrapper


@admin_bp.route('/dashboard', methods=['GET'])
@jwt_required()
@librarian_required
def dashboard_stats():
    """Summary stats for librarian dashboard"""
    total_books = Book.query.filter_by(is_active=True).count()
    total_users = User.query.filter_by(role='student', is_active=True).count()
    active_borrowings = BorrowingHistory.query.filter_by(is_returned=False).count()
    overdue = BorrowingHistory.query.filter(
        BorrowingHistory.is_returned == False,
        BorrowingHistory.due_date < date.today()
    ).count()

    return jsonify({
        'total_books': total_books,
        'total_students': total_users,
        'active_borrowings': active_borrowings,
        'overdue_borrowings': overdue
    }), 200


@admin_bp.route('/analytics/popular-books', methods=['GET'])
@jwt_required()
@librarian_required
def popular_books():
    """Top 10 most borrowed books"""
    results = db.session.query(
        Book.title, Book.author,
        func.count(BorrowingHistory.id).label('borrow_count')
    ).join(BorrowingHistory, Book.id == BorrowingHistory.book_id)\
     .group_by(Book.id)\
     .order_by(func.count(BorrowingHistory.id).desc())\
     .limit(10).all()

    return jsonify([{
        'title': r.title,
        'author': r.author,
        'borrow_count': r.borrow_count
    } for r in results]), 200


@admin_bp.route('/analytics/category-distribution', methods=['GET'])
@jwt_required()
@librarian_required
def category_distribution():
    """Borrowing distribution by category"""
    results = db.session.query(
        Category.name,
        func.count(BorrowingHistory.id).label('count')
    ).join(Book, Category.id == Book.category_id)\
     .join(BorrowingHistory, Book.id == BorrowingHistory.book_id)\
     .group_by(Category.name)\
     .order_by(func.count(BorrowingHistory.id).desc()).all()

    return jsonify([{'category': r.name, 'count': r.count} for r in results]), 200


@admin_bp.route('/analytics/monthly-trend', methods=['GET'])
@jwt_required()
@librarian_required
def monthly_trend():
    """Monthly borrowing trend for last 12 months"""
    results = db.session.query(
        func.year(BorrowingHistory.issue_date).label('year'),
        func.month(BorrowingHistory.issue_date).label('month'),
        func.count(BorrowingHistory.id).label('count')
    ).group_by('year', 'month')\
     .order_by('year', 'month')\
     .limit(12).all()

    return jsonify([{
        'year': r.year, 'month': r.month, 'count': r.count
    } for r in results]), 200


@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@librarian_required
def get_users():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    query = User.query.filter_by(role='student')
    if search:
        query = query.filter(
            db.or_(User.name.ilike(f'%{search}%'), User.email.ilike(f'%{search}%'))
        )
    pagination = query.paginate(page=page, per_page=20, error_out=False)
    return jsonify({
        'users': [u.to_dict() for u in pagination.items],
        'total': pagination.total
    }), 200


@admin_bp.route('/users/<int:user_id>/toggle', methods=['POST'])
@jwt_required()
@librarian_required
def toggle_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_active = not user.is_active
    db.session.commit()
    status = 'activated' if user.is_active else 'deactivated'
    return jsonify({'message': f'User {status}', 'user': user.to_dict()}), 200
