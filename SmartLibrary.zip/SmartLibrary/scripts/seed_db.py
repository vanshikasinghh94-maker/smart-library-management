"""
Database Seeder
Run: python scripts/seed_db.py
Seeds the database with sample categories, books, and users for testing.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app, db, bcrypt
from app.models import User, Book, Category


def seed():
    app = create_app()
    with app.app_context():
        print("Seeding database...")

        # Categories
        categories = [
            Category(name='Computer Science', description='Programming, algorithms, data structures'),
            Category(name='Mathematics', description='Pure and applied mathematics'),
            Category(name='Physics', description='Classical and modern physics'),
            Category(name='Fiction', description='Novels and short stories'),
            Category(name='Science', description='General science and biology'),
            Category(name='History', description='World history and biographies'),
            Category(name='Self-Help', description='Personal development and productivity'),
        ]
        for cat in categories:
            if not Category.query.filter_by(name=cat.name).first():
                db.session.add(cat)
        db.session.commit()
        print(f"  Added {len(categories)} categories")

        cs = Category.query.filter_by(name='Computer Science').first()
        math = Category.query.filter_by(name='Mathematics').first()
        fiction = Category.query.filter_by(name='Fiction').first()
        sci = Category.query.filter_by(name='Science').first()

        # Books
        books_data = [
            ('Introduction to Algorithms', 'Cormen, Leiserson, Rivest', cs, '9780262033848', 5),
            ('Clean Code', 'Robert C. Martin', cs, '9780132350884', 3),
            ('The Pragmatic Programmer', 'Hunt & Thomas', cs, '9780135957059', 4),
            ('Python Crash Course', 'Eric Matthes', cs, '9781593279288', 6),
            ('Design Patterns', 'Gang of Four', cs, '9780201633610', 2),
            ('Calculus', 'James Stewart', math, '9781285740621', 4),
            ('Linear Algebra Done Right', 'Sheldon Axler', math, '9783319307657', 3),
            ('Discrete Mathematics', 'Kenneth Rosen', math, '9780073383095', 5),
            ('A Brief History of Time', 'Stephen Hawking', sci, '9780553380163', 4),
            ('The Selfish Gene', 'Richard Dawkins', sci, '9780198788607', 3),
            ('To Kill a Mockingbird', 'Harper Lee', fiction, '9780061935466', 5),
            ('1984', 'George Orwell', fiction, '9780451524935', 4),
            ('The Great Gatsby', 'F. Scott Fitzgerald', fiction, '9780743273565', 3),
            ('Atomic Habits', 'James Clear', None, '9780735211292', 6),
            ('Deep Work', 'Cal Newport', None, '9781455586691', 4),
        ]

        for title, author, category, isbn, copies in books_data:
            if not Book.query.filter_by(isbn=isbn).first():
                book = Book(
                    title=title, author=author,
                    category=category, isbn=isbn,
                    total_copies=copies, available_copies=copies,
                    year_published=2020
                )
                db.session.add(book)
        db.session.commit()
        print(f"  Added {len(books_data)} books")

        # Users
        users = [
            {'name': 'Admin Librarian', 'email': 'librarian@library.edu',
             'password': 'librarian123', 'role': 'librarian'},
            {'name': 'Vanshika Singh', 'email': 'vanshika@student.edu',
             'password': 'student123', 'role': 'student', 'enrollment_no': 'O23BCA110100'},
            {'name': 'Rahul Sharma', 'email': 'rahul@student.edu',
             'password': 'student123', 'role': 'student', 'enrollment_no': 'O23BCA110101'},
            {'name': 'Priya Verma', 'email': 'priya@student.edu',
             'password': 'student123', 'role': 'student', 'enrollment_no': 'O23BCA110102'},
        ]

        for u in users:
            if not User.query.filter_by(email=u['email']).first():
                user = User(
                    name=u['name'], email=u['email'],
                    password_hash=bcrypt.generate_password_hash(u['password']).decode('utf-8'),
                    role=u['role'],
                    enrollment_no=u.get('enrollment_no')
                )
                db.session.add(user)
        db.session.commit()
        print(f"  Added {len(users)} users")

        print("\nSeeding complete!")
        print("\nDefault credentials:")
        print("  Librarian: librarian@library.edu / librarian123")
        print("  Student:   vanshika@student.edu  / student123")


if __name__ == '__main__':
    seed()
