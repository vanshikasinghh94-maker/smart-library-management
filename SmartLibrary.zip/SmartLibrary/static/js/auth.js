// Auth - Login / Logout

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (!res.ok) {
            showAlert(data.error || 'Login failed', 'danger');
            return;
        }

        localStorage.setItem('access_token', data.access_token);
        localStorage.setItem('refresh_token', data.refresh_token);
        localStorage.setItem('user', JSON.stringify(data.user));

        if (data.user.role === 'librarian') {
            window.location.href = '/admin';
        } else {
            window.location.href = '/dashboard';
        }
    } catch (err) {
        showAlert('Network error. Please try again.', 'danger');
    }
});

function showAlert(msg, type = 'info') {
    const box = document.getElementById('alert-box');
    box.innerHTML = `<div class="alert alert-${type} py-2">${msg}</div>`;
    setTimeout(() => box.innerHTML = '', 4000);
}

function logout() {
    localStorage.clear();
    window.location.href = '/';
}
