// Student Dashboard JS

const token = localStorage.getItem('access_token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

if (!token || user.role !== 'student') {
    window.location.href = '/';
}

document.getElementById('user-name').textContent = user.name || 'Student';

async function apiFetch(url, options = {}) {
    options.headers = { ...options.headers, 'Authorization': `Bearer ${token}` };
    const res = await fetch(url, options);
    if (res.status === 401) { logout(); return null; }
    return res.json();
}

function logout() {
    localStorage.clear();
    window.location.href = '/';
}

async function loadRecommendations() {
    const data = await apiFetch('/api/recommendations/');
    const el = document.getElementById('recommendations-list');
    if (!data || !data.recommendations.length) {
        el.innerHTML = '<p class="text-muted">No recommendations yet. Borrow more books!</p>';
        return;
    }
    el.innerHTML = data.recommendations.map(b => `
        <div class="book-card">
            <div class="book-title">${b.title}</div>
            <div class="book-meta">${b.author} · ${b.category || 'General'}</div>
            <span class="${b.is_available ? 'badge-available' : 'badge-unavailable'}">
                ${b.is_available ? `${b.available_copies} available` : 'Unavailable'}
            </span>
        </div>
    `).join('');
}

async function loadActiveBorrowings() {
    const data = await apiFetch('/api/borrowing/active');
    const el = document.getElementById('active-borrowings');
    if (!data || !data.length) {
        el.innerHTML = '<p class="text-muted">No active borrowings.</p>';
        return;
    }
    el.innerHTML = data.map(r => `
        <div class="book-card ${r.is_overdue ? 'border-danger' : ''}">
            <div class="book-title">${r.book_title}</div>
            <div class="book-meta">Due: ${r.due_date} ${r.is_overdue ? '⚠️ OVERDUE' : ''}</div>
            ${r.fine_amount > 0 ? `<small class="text-danger">Fine: ₹${r.fine_amount}</small>` : ''}
        </div>
    `).join('');
}

async function loadNotifications() {
    const data = await apiFetch('/api/notifications/');
    const el = document.getElementById('notifications-list');
    const unread = await apiFetch('/api/notifications/unread-count');

    if (unread && unread.unread_count > 0) {
        const badge = document.getElementById('notif-badge');
        badge.textContent = unread.unread_count;
        badge.classList.remove('d-none');
    }

    if (!data || !data.length) {
        el.innerHTML = '<p class="text-muted">No notifications.</p>';
        return;
    }
    el.innerHTML = data.slice(0, 10).map(n => `
        <div class="notif-item ${n.type}">
            <strong>${n.title}</strong><br>
            <small>${n.message}</small>
            <div class="text-muted" style="font-size:.75rem">${n.created_at.split('T')[0]}</div>
        </div>
    `).join('');
}

async function searchBooks() {
    const q = document.getElementById('search-input').value;
    if (!q) return;
    const data = await apiFetch(`/api/books/?search=${encodeURIComponent(q)}`);
    const el = document.getElementById('search-results');
    if (!data || !data.books.length) {
        el.innerHTML = '<p class="text-muted">No books found.</p>';
        return;
    }
    el.innerHTML = `<div class="row g-2">${data.books.map(b => `
        <div class="col-md-6">
            <div class="book-card">
                <div class="book-title">${b.title}</div>
                <div class="book-meta">${b.author} · ${b.category || ''}</div>
                <span class="${b.is_available ? 'badge-available' : 'badge-unavailable'}">
                    ${b.is_available ? `${b.available_copies} available` : 'Unavailable'}
                </span>
            </div>
        </div>
    `).join('')}</div>`;
}

document.getElementById('search-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') searchBooks();
});

// Init
loadRecommendations();
loadActiveBorrowings();
loadNotifications();
