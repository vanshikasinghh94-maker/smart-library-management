// Admin Dashboard JS

const token = localStorage.getItem('access_token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

if (!token || user.role !== 'librarian') {
    window.location.href = '/';
}

async function apiFetch(url, options = {}) {
    options.headers = { ...options.headers, 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
    const res = await fetch(url, options);
    if (res.status === 401) { logout(); return null; }
    return res.json();
}

function logout() {
    localStorage.clear();
    window.location.href = '/';
}

async function loadStats() {
    const data = await apiFetch('/api/admin/dashboard');
    if (!data) return;
    document.getElementById('stat-books').textContent = data.total_books;
    document.getElementById('stat-students').textContent = data.total_students;
    document.getElementById('stat-active').textContent = data.active_borrowings;
    document.getElementById('stat-overdue').textContent = data.overdue_borrowings;
}

async function loadActiveBorrowings() {
    const data = await apiFetch('/api/borrowing/active');
    const el = document.getElementById('active-borrowings');
    if (!data || !data.length) { el.innerHTML = '<p class="text-muted">None.</p>'; return; }
    el.innerHTML = data.map(r => `
        <div class="book-card d-flex justify-content-between align-items-center">
            <div>
                <div class="book-title">${r.book_title}</div>
                <div class="book-meta">Student #${r.user_id} · Due: ${r.due_date}</div>
            </div>
            <button class="btn btn-sm btn-warning" onclick="returnBook(${r.id})">Return</button>
        </div>
    `).join('');
}

async function returnBook(recordId) {
    const data = await apiFetch(`/api/borrowing/return/${recordId}`, { method: 'POST' });
    if (data) {
        alert(`Book returned. Fine: ₹${data.fine || 0}`);
        loadStats();
        loadActiveBorrowings();
    }
}

async function addBook() {
    const body = {
        title: document.getElementById('book-title').value,
        author: document.getElementById('book-author').value,
        isbn: document.getElementById('book-isbn').value,
        total_copies: parseInt(document.getElementById('book-copies').value) || 1
    };
    if (!body.title || !body.author) { alert('Title and author required'); return; }
    const data = await apiFetch('/api/books/', { method: 'POST', body: JSON.stringify(body) });
    if (data && data.book) {
        alert(`Book added: ${data.book.title} (ID: ${data.book.id})`);
        document.getElementById('book-title').value = '';
        document.getElementById('book-author').value = '';
        document.getElementById('book-isbn').value = '';
        loadStats();
    }
}

async function issueBook() {
    const body = {
        user_id: parseInt(document.getElementById('issue-user-id').value),
        book_id: parseInt(document.getElementById('issue-book-id').value)
    };
    if (!body.user_id || !body.book_id) { alert('Student ID and Book ID required'); return; }
    const data = await apiFetch('/api/borrowing/issue', { method: 'POST', body: JSON.stringify(body) });
    if (data && data.record) {
        alert(`Issued! Due: ${data.record.due_date}`);
        loadStats();
        loadActiveBorrowings();
    }
}

async function loadPopularChart() {
    const data = await apiFetch('/api/admin/analytics/popular-books');
    if (!data || !data.length) return;
    const ctx = document.getElementById('popular-chart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(d => d.title.substring(0, 25)),
            datasets: [{
                label: 'Times Borrowed',
                data: data.map(d => d.borrow_count),
                backgroundColor: '#0d6efd88',
                borderColor: '#0d6efd',
                borderWidth: 1
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
}

loadStats();
loadActiveBorrowings();
loadPopularChart();
